/* Auteur: yorick LE MOING Groupe: 6*/
#ifndef FENETRE1_H
#define FENETRE1_H


void AffichageAccueil();
/* affiche l'ecran des paramètre */

void ChoixAccueil(int choix[2]);
/* renvoie les paramètre souhaiter
 * prend un tableau en argument,
 * 1er case: nombre de joueur
 * 2eme case: taille grille
 */


#endif /* FENETRE1_H */
