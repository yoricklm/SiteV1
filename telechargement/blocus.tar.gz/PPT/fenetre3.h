/* Auteur: yorick LE MOING Groupe: 6*/
#ifndef FENETRE3_H
#define FENETRE3_H

void AffichageResultat(int joueur);
/* Affiche le gagnant et les choix (recommencer ou quitter)
 * 1er argument : le joueur gagnant
 */

int ChoixFin(void);
/*renvoie les choix
 *1 pour recommencer
 *-1 pour quitter
 */ 

#endif /* FENETRE3_H */
